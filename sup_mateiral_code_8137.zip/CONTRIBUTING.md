* Please follow the normal GitHub workflow of creating a pull request with descriptive commit messages
* Please follow the PEP8 standard of python code style
